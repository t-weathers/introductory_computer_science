#include <string>
#include <vector>
#include "game.h"
using namespace std;

int main(){
	game antsvsbees;
	antsvsbees.run_game();
	return 0;
}
