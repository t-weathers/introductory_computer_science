#include "ant.h"
using namespace std;

#ifndef LONG_THROWER_H
#define LONG_THROWER_H
class long_thrower : public ant{
  public:
    long_thrower(int location);
    void action();

};
#endif
