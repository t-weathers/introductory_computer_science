#include "bee.h"
using namespace std;

/********************************************************************
** Function: bee()
** Description: sets the bee fields
** parameters: n/a
********************************************************************/
bee::bee(){
  *armor = 3;
  *location = 9;
}

void bee::action(){

}
