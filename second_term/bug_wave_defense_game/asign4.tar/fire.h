#include "ant.h"
using namespace std;

#ifndef FIRE_H
#define FIRE_H
class fire : public ant{
  public:
    fire(int location);
    void action();

};
#endif
